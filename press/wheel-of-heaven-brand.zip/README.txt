Wheel of Heaven — Brand Assets
=================================

This archive contains the official logos and brand materials for
Wheel of Heaven. Files are licensed CC0-1.0 (public domain).

Contents
--------
- logomark.svg                The hexagonal mark on its own. Scales freely.
- wordmark.svg                The full "WHEEL of HEAVEN" type lockup.
- wheel-of-heaven.{png,jpg,webp}        Horizontal share image, 1200x630.
- wheel-of-heaven-square.{png,jpg,webp} Square share image, 1080x1080.
- favicon.svg                 Vector favicon.
- favicon-{16..512}.png       Raster favicons.
- palette.txt                 Hex codes for the Bifrost palette.

Typography
----------
We use four typeface layers:

  Layer 1 — Reading       Jost            Body, UI, primary
  Layer 2 — Framing       Space Grotesk   Titles, framing, OG cards
  Layer 3 — Source        IBM Plex Serif  Quotations, source material
  Layer 4 — Technical     iA Writer Quattro  Chips, monospace, metadata

All four are open-source. Sources: fonts.google.com, github.com/iaolo/iA-Fonts

Press contact
-------------
press@wheelofheaven.world

Project home
------------
https://www.wheelofheaven.world/press/

License
-------
All assets in this archive are released under CC0-1.0 (public domain
dedication). Use them however you want. Attribution is appreciated but
not required.
